

import secrets
print(secrets.token_hex(16))  # Example: 'e5b58b2bf5b19cbb7c9e12e6d6f1234e'